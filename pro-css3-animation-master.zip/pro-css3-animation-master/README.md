# Apress Source Code

This repository accompanies [*Pro CSS3 Animation*](http://www.apress.com/9781430247227) by Dudley Storey (Apress, 2012).

![Cover image](9781430247227.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

## Releases

Release v1.0 corresponds to the code in the published book, without corrections or updates.

## Contributions

See the file Contributing.md for more information on how you can contribute to this repository.
