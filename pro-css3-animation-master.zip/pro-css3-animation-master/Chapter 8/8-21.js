$(function() {
    $("#at").click(function() { $(".box").toggleClass("wobble"); });
});